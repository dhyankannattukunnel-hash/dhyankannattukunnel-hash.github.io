import mysql.connector as sql
import os

CFG = {
    "host": os.getenv("DB_HOST", "localhost"),
    "user": os.getenv("DB_USER", "root"),
    "password": os.getenv("DB_PASS", ""),
    "database": os.getenv("DB_NAME", "bakery")
}

def get_conn():
    return sql.connect(**CFG)

def add_product(name, price, stock):
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("INSERT INTO products(name, price, stock) VALUES(%s,%s,%s)", (name, price, stock))
        conn.commit()

def list_products():
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("SELECT id,name,price,stock FROM products ORDER BY id")
        for row in cur.fetchall():
            print(row)

def main():
    while True:
        print("\n1) Add product  2) List products  3) Exit")
        ch = input("> ").strip()
        if ch == "1":
            n = input("Name: ")
            p = float(input("Price: "))
            s = int(input("Stock: "))
            add_product(n, p, s)
        elif ch == "2":
            list_products()
        else:
            break

if __name__ == "__main__":
    main()
