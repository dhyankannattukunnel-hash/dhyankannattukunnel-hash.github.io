# Bakery Management System — CLI Version

This project is a **Python + MySQL Bakery Management System** with Admin and Customer modules.

### Features
- Admin:
  - Add new items to the menu
  - Remove items
  - Update prices
  - View all items
- Customer:
  - View menu and order products
  - Auto-generated receipt with date & time
  - Simple payment handling

### Usage
1. Make sure MySQL is installed and running.
2. Create a database named `bakery`.
3. Edit `bakery.py` connection parameters if needed.
4. Run: `python bakery.py`

Admin password = **123456**

---
This is a simple learning project for managing a bakery's menu and billing system.
