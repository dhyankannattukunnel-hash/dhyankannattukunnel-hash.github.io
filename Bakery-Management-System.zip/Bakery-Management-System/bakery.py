import mysql.connector as ms
import datetime

# Connect to MySQL
con = ms.connect(host="localhost", user="root", passwd="tiger", database='bakery')
cursor = con.cursor()

# Check connection
if con.is_connected():
    print("Connected to MySQL database")

# Create Menu table if not exists
cursor.execute('''
    CREATE TABLE IF NOT EXISTS Menu(
        product_id INT AUTO_INCREMENT PRIMARY KEY,
        product_name VARCHAR(255),
        product_price INT
    )
''')

# Insert initial data if Menu is empty
cursor.execute("SELECT COUNT(*) FROM Menu")
if cursor.fetchone()[0] == 0:
    cursor.executemany('''
        INSERT INTO Menu (product_name, product_price) VALUES (%s, %s)
    ''', [
        ('Cake', 400),
        ('Bread', 35),
        ('Cold Coffee', 50),
        ('Doughnuts', 80),
        ('Sandwich', 120)
    ])
    con.commit()
    print("Initial data inserted into Menu table")

def display_items(curs):
    curs.execute("SELECT * FROM Menu")
    out = curs.fetchall()
    print("List of items:")
    print("{:<5} {:<20} {:<10}".format("ID", "Name", "Price"))
    for row in out:
        print("{:<5} {:<20} ₹{:<10}".format(row[0], row[1], row[2]))

def admin_login(connection, cur):
    while True:
        print("\n---------Welcome! You are logged in as Admin!----------")
        print("1. Add an item\n2. Remove an item\n3. Update item price\n4. See all the items\n5. Exit")
        try:
            choice = int(input("Enter your choice: "))
        except ValueError:
            print("Invalid input! Please enter a number.")
            continue
        if choice == 1:
            product_name = input("Enter product name: ")
            try:
                product_price = int(input("Enter product price: "))
                cur.execute("INSERT INTO Menu(product_name, product_price) VALUES (%s, %s)", (product_name, product_price))
                connection.commit()
                print("The item has been added!")
            except ValueError:
                print("Invalid price! Please enter a number.")
        elif choice == 2:
            display_items(cur)
            try:
                prdt_id = int(input("Enter product ID to remove: "))
                cur.execute("DELETE FROM Menu WHERE product_id=%s", (prdt_id,))
                if cur.rowcount == 0:
                    print("Product not found!")
                else:
                    connection.commit()
                    print("Item removed.")
            except ValueError:
                print("Invalid input! Please enter a valid number.")
        elif choice == 3:
            display_items(cur)
            try:
                prdt_id = int(input("Enter product ID to update: "))
                new_price = int(input("Enter new price: "))
                cur.execute("UPDATE Menu SET product_price=%s WHERE product_id=%s", (new_price, prdt_id))
                if cur.rowcount == 0:
                    print("Product not found!")
                else:
                    connection.commit()
                    print("Price updated.")
            except ValueError:
                print("Invalid input! Please enter valid numbers.")
        elif choice == 4:
            display_items(cur)
        elif choice == 5:
            print("Exiting admin panel...\n")
            break
        else:
            print("Invalid choice!")

def customer_login(connection, cur):
    while True:
        print("\n-----------Welcome, You are logged in as Customer!-------------")
        print("1. Billing\n2. Exit")
        try:
            choice = int(input("Enter your choice: "))
        except ValueError:
            print("Invalid input.")
            continue
        if choice == 1:
            name = input("Enter your name: ")
            print(f"\nHello {name}, here's our menu:")
            display_items(cur)
            total = 0
            items = []
            while True:
                try:
                    id = int(input("Enter product ID: "))
                    quantity = int(input("Enter quantity: "))
                    cur.execute("SELECT * FROM Menu WHERE product_id=%s", (id,))
                    item = cur.fetchone()
                    if item:
                        name, price = item[1], item[2]
                        item_total = price * quantity
                        total += item_total
                        items.append((name, quantity, item_total))
                        more = input("Add more items? (Y/N): ").strip().lower()
                        if more == "n":
                            break
                    else:
                        print("Invalid product ID!")
                except ValueError:
                    print("Please enter valid numbers.")
            if total > 0:
                print("\n------------- Sunny Baker's Receipt --------------")
                print(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
                print("{:<20} {:<10} {:<15}".format("Item", "Qty", "Total Price"))
                print("-"*45)
                for item in items:
                    print("{:<20} {:<10} ₹{:<10.2f}".format(item[0], item[1], item[2]))
                print("-"*45)
                print("{:<20} {:<10} ₹{:<10.2f}".format("Total", "", total))
                while True:
                    try:
                        payment = float(input("Enter payment amount: ₹"))
                        if payment >= total:
                            change = payment - total
                            print("Payment accepted. Change: ₹{:.2f}".format(change))
                            break
                        else:
                            print(f"Insufficient payment. Balance due: ₹{total - payment:.2f}")
                    except ValueError:
                        print("Enter a valid amount.")
                print("Thank you! Have a sweet day!\n")
        elif choice == 2:
            print("Exiting customer panel...\n")
            break
        else:
            print("Invalid choice. Try again.")

def main():
    while True:
        print("\n" + "*" * 50)
        print("Welcome to Sunny Bakery!".center(50))
        print("*" * 50)
        print("1. Admin Login\n2. Customer Login\n3. Exit")
        choice = input("Enter your choice: ")
        if choice == '1':
            pwd = input("Enter Admin password: ")
            if pwd == "123456":
                admin_login(con, cursor)
            else:
                print("Incorrect password!")
        elif choice == '2':
            customer_login(con, cursor)
        elif choice == '3':
            print("Thank you! Exiting...")
            break
        else:
            print("Invalid choice! Try again.")

# Run main function
main()
